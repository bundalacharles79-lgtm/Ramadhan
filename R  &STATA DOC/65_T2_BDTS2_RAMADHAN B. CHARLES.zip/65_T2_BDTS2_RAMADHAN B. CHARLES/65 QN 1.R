
################################# TEST 2
#################################  MODULE INSTRUCTURE MR EDWIN MAGOTI 

################################# BACHELOR OF DEGREE IN DATA SCIENCE (BDTS) II

################################# MODULE TITLE: DATA ANALYSIS WITH R

################################# MODULE CODE: DSU07317

##########%%%%% GROUP  TASK ASSIGNMENT 02

##############GROUP NAMES
#RAHEL RICHARD KAPANGE	  EASTC/BDTS/25/01861
#RAMADHAN BUNDALA CHARLES EASTC/BDTS/25/02683
#RICHARD JUMA CHANDARAU 	EASTC/BDTS/25/02404
#SAID MUSSA KANENGO     	EASTC/BDTS/25/02610
#REBEKA JAMES BOMAN	      EASTC/BDTS/25/02580

##### QUESTION 01

#### (a) step 1 Hypothesis
#We want to test whether Teaching Method (Lecture vs. Blended), Study Environment (Home vs. Library), and their interaction affect exam scores.
# Null hypothesis (H₀):
#Teaching method, study environment, and their interaction have no effect on students’ scores.

# Alternative hypothesis (H₁):
# At least one of these factors (method, environment, or their interaction) significantly affects scores.


###(b) step 2 fit the model in R
#We use a two-way ANOVA (since both predictors are categorical)

# Load data set
data <- read.csv("C:/Q1dataset.csv")
print(data)

# Fit two-way ANOVA with interaction
model <- aov(Score ~ TeachingMethod * Environment, data = data)
print(model)
summary(model)

########### View summary This model tests
# Main effect of Teaching Method
# Main effect of Environment
# Interaction effect (Teaching Method × Environment)

#Step (c) Test Interaction Effect
#From the ANOVA table, check the p-value for Teaching Method:Environment.
# there fore  p < 0.05, the interaction  between Teaching Method vs Environment.is statistically significant.

#Given the data set values:
# Lecture + Home scores average around 65–67.
# Lecture + Library scores average around 72–74.
# Blended + Home scores average around 70–72.
# Blended + Library scores average around 85–87.
#The gap between Home vs. Library is much larger for Blended than for Lecture, suggesting the interaction effect will be significant.


#Step (d) Interaction Plot
interaction.plot(data$Environment, data$TeachingMethod, data$Score,
                 col=c("green","purple"), lwd=2, ylab="Mean Score",
                 xlab="Study Environment", trace.label="Teaching Method")


#there fore
# Lecture scores rise slightly from Home → Library.
# Blended scores rise sharply from Home → Library.
#The non-parallel lines indicate a strong interaction.

#Step (e) Advice to the University
#The effectiveness of teaching method depends on study environment.
# Blended learning is highly effective in the Library (scores ~85+), but only moderately better than Lecture at Home.
#Advice: Encourage Blended learning in structured environments (Library) to maximize performance.






