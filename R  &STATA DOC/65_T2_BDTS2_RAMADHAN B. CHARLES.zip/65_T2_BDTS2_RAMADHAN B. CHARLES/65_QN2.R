####**********************************************
###  QUESTION 2

#Step (a) Fit the Model in R
# We want to study how Education, Experience, Gender, and Urban residence affect Income. The appropriate model is a multiple linear regression:

# Load data set
data <- read.csv("C:/Qdataset.csv")
print(data)
# Fit regression model
model <- lm(Income ~ Education + Experience + Gender + Urban, data = data)

# View summary
summary(model)

#  NOTE Fit regression model This gives us estimated coefficients, their significance, and overall model fit.

#Step (b) Interpret the Regression Coefficients
# Intercept: Baseline income when all predictors = 0 (not meaningful in practice, but sets the reference point).
# Education: Expected change in income per additional year of schooling, holding other factors constant.
#Positive coefficient means more schooling increases income.
# Experience: Expected change in income per additional year of work experience.
# Positive coefficient means more experience increases income.
# Gender (1 = Male): Difference in income between males and females, controlling for other variables.
#Positive coefficient means males earn more on average.
# Urban (1 = Urban): Difference in income between urban and rural residents.
# Positive coefficient means urban residents earn more.

#Step (c) Test Overall Significance of the Model
#Use the F-test from the regression summary:
anova(model)


#If the F-statistic p-value < 0.05, the model is statistically significant overall (predictors jointly explain variation in income).
  
  #Step (d) Joint Significance of Education and Experience
  #We test whether Education and Experience together significantly predict income:
  # Test joint significance
  library(car)
linearHypothesis(model, c("Education=0", "Experience=0"))# If the p-value < 0.05, Education and Experience are jointly significant.

#####Step (e) Check Model Assumptions
#We use diagnostic plots:
par(mfrow=c(2,2))
plot(model)


# Residuals vs Fitted: Checks linearity and homoscedasticity.
# Normal Q-Q: Checks normality of residuals.
# Scale-Location: Checks equal variance.
# Residuals vs Leverage: Identifies influential points.

#####%%%%%%%%%%%Interpretation & Advice
# Education and Experience are likely positive and significant predictors — more schooling and more years of work increase income.
# Gender and Urban residence may also play roles: urban residents and males often show higher incomes in such datasets.
# The university/researcher can conclude that human capital (education + experience) strongly influences income, but location and gender disparities also matter.


